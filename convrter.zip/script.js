document.addEventListener('DOMContentLoaded', function () {
    const convertBtn = document.getElementById('convertBtn');
    const amountInput = document.getElementById('amount');
    const fromCurrencySelect = document.getElementById('from');
    const toCurrencySelect = document.getElementById('to');
    const resultDiv = document.getElementById('result');
  
    convertBtn.addEventListener('click', async function () {
      const amount = amountInput.value;
      const fromCurrency = fromCurrencySelect.value;
      const toCurrency = toCurrencySelect.value;
  
      // Replace with your API call to perform the currency conversion
      const conversionRate = await fetchConversionRate(fromCurrency, toCurrency);
      const convertedAmount = (amount * conversionRate).toFixed(2);
  
      resultDiv.textContent = `${amount} ${fromCurrency} is approximately ${convertedAmount} ${toCurrency}`;
    });
  
    // Replace this function with an actual API call to get the conversion rate
    async function fetchConversionRate(fromCurrency, toCurrency) {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulated conversion rate (replace with actual API response)
      const conversionRates = {
        'USD_INR': 73.5,
        'USD_EUR': 0.85,
        // Add more conversion rates here
      };
  
      const rateKey = `${fromCurrency}_${toCurrency}`;
      return conversionRates[rateKey] || 1;
    }
  });
  