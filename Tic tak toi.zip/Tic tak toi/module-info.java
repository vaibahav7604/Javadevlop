module RuralBankingManagement {

    requires javafx.fxml;
    requires javafx.controls;

    opens com.akgarg.bankingsystem;
}