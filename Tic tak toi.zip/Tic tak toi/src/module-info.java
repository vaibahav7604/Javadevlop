module SampleJavaFX {

    requires javafx.fxml;
    requires javafx.controls;

    opens TicTacToeJavaFX;
}